package SM.RRA.IU;

/**
 *
 * @author raul
 */

/**
 * 
 * Tipo de dato enumerado que nos ayudará a la hora de poder distinguir entre
 * la forma que queremos que el método paint dibuje.
 * 
 */
public enum tipos {
    LINEA, RECTANGULO, ELIPSE, CURVA, LIBRE, SMILE
}
